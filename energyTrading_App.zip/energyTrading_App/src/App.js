import "./App.css";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.bundle";
import LandingPage from "./components/LandingPage";
import { Navigate, Route, Routes } from "react-router-dom";
import BuyAndSellTabs from "./components/BuyAndSellTabs";
import OrderAccepted from "./components/dialogBoxes/OrderAccepted";
import { LoaderProvider } from "./components/LoaderContext";


function App() {
  return (
    <LoaderProvider>
      <div className="App">
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/buyandsell" element={<BuyAndSellTabs />} />
          <Route path="/dialog" element={<OrderAccepted />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
        {/* <LandingPage /> */}
      </div>
    </LoaderProvider>
  );
}

export default App;
