export function getDateFromTimestamp(timestamp) {
    return new Date(+timestamp).toLocaleDateString();
  }