export function getLatituteLongitude(cordinate) {
  // return cordinate.substring(0, cordinate.indexOf("°"));
  return cordinate.includes("°")
    ? cordinate.substring(0, cordinate.indexOf("°"))
    : cordinate;
}
