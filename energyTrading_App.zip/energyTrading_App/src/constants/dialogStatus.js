import {
  FaCheckCircle,
  FaRegCheckCircle,
  FaRegTimesCircle,
  FaTimesCircle,
} from "react-icons/fa";
import { FiClock } from "react-icons/fi";
import { GiHourglass } from "react-icons/gi";
import { IoIosCheckmarkCircle } from "react-icons/io";
import { IoIosSync } from "react-icons/io";
import { BsExclamationTriangle } from "react-icons/bs";

const iconSize = "85";
export default {
  placed: {
    icon: <FaRegCheckCircle size={iconSize} color="0000FF" />,
    title: "Request Submitted",
    subtitle: "A request has been placed for your order.",
  },
  accepted: {
    icon: <FaRegCheckCircle size={iconSize} color="0000FF" />,
    subtitle: "Your order got accepted.",
  },
  rejected: {
    icon: <FaRegTimesCircle size={iconSize} color="red" />,
    subtitle: "Order rejected !",
  },
  paymentSuccess: {
    icon: <FaCheckCircle size={iconSize} color="green" />,
    title: "Payment Successful",
    subtitle: "We have recieved your payment. Thanks!!",
  },
  paymentFailed: {
    icon: <FaTimesCircle size={iconSize} color="red" />,
    title: "Payment Unsuccessful",
    subtitle: "Your payment failed due to some technical error.",
  },
  orderAccepted: {
    icon: <FiClock size={iconSize} color="green" />,
    title: "Order Accepted !",
    subtitle: "Awaiting for payment from Buyer !!",
  },
  pendingOrder: {
    icon: <GiHourglass size={iconSize} color="orange" />,
    title: "Order Accepted, Awaiting Payment",
    subtitle: "Payment pending from buyer...",
  },
  inTransit: {
    icon: <IoIosSync size={iconSize} color="blue" />,
    title: "In Transit",
    subtitle: "Energy transaction in progress...",
  },
  transferCompleted: {
    icon: <IoIosCheckmarkCircle size={iconSize} color="green" />,
    title: "Completed",
    subtitle: "Energy transfer completed !!",
  },
  transitError: {
    icon: <BsExclamationTriangle size={iconSize} color="red" />,
    title: "Error Transit",
    subtitle: "Error in energy transaction !!",
  }
};
