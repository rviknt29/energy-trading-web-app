export const OrderStatus = [
    "Pending Order",
    "Order Rejected",
    "Awaiting Payment",
    "Error Payment",
    "Payment Success",
    "In Transit",
    "Completed",
    "ErrorTransit",
];

export const handleColorCode = (status) => {
    const colorCodes = {
      "Pending Order": "orange",
      "Order Rejected": "red",
      "Awaiting Payment": "#d24e2b",
      "Error Payment": "red",
      "Payment Success": "green",
      "In Transit": "magenta",
      "Completed": "#1873a0",
      "ErrorTransit": "black",
    };
    return colorCodes[status] || ""; // Return an empty string if the status is not found
};