import { createContext } from "react";
import { useState } from "react";

const LoaderContext = createContext();

function LoaderProvider(props) {
  const [loading, setLoading] = useState(false);

  const loader = {
    setLoading,
    loading,
  };

  return (
    <LoaderContext.Provider value={loader}>
      {props.children}
    </LoaderContext.Provider>
  );
}

export { LoaderContext, LoaderProvider };
