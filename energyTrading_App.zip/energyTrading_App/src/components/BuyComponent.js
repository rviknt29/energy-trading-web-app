import React, { useState, useEffect } from "react";
import BuyDetailsCard from "./BuyDetailsCard";
import RenderMap from "./RenderMap";
import { getProsumersWithEnergy, transferInitiatedOrder } from "../services/services";
import { getLatituteLongitude } from "../helpers/map";

const BuyComponent = () => {
  const [locationPoints, setLoactionPoints] = useState([]);
  const [energyVolume, setEnergyVolume] = useState("");
  const [searchLocationPoints, setSearchLocationPoints] = useState(false);
  const [defaultAccount, setDefaultAccount] = useState(null);

  useEffect(() => {
    checkWalletIsConnected();
  }, []);

  const checkWalletIsConnected = async () => {
    const { ethereum } = window;
    if (!ethereum) {
      console.log("Make sure you have metamask!");
      return;
    } else {
      console.log("We have the ethereum object", ethereum);
    }

    ethereum.request({ method: "eth_accounts" }).then((accounts) => {
      if (accounts.length !== 0) {
        const account = accounts[0];
        console.log("Found an account:", account);

        setDefaultAccount(account);
        // window.localStorage.setItem("accountAddr", defaultAccount);
      } else {
        console.log("No account found");
      }
    });
  };

  

  const handleEnergyVolumeChangeEvent = (event) => {
    setEnergyVolume(event.target.value);
    window.localStorage.setItem("energyVolume", event.target.value);
  };

  const handleSearchEvent = () => {
    setSearchLocationPoints(true);
    let energyVal = parseInt(energyVolume);
    let accountAddr = window.localStorage.getItem("accountAddr");
    
    getProsumersWithEnergy(
      energyVal,
      accountAddr
    ).then((data) => {
      // console.log("getProsumersWithEnergy called on search click", data);
      setLoactionPoints(
        data.map((el) => {
          return {
            cordinates: [
              getLatituteLongitude(el.prosumer_obj[2]),
              getLatituteLongitude(el.prosumer_obj[3]),
            ],
            sellerInfo: {
              name: el.prosumer_obj["name"],
              phone: el.prosumer_obj["phone"],
              location: el.prosumer_obj["location"],
              energyVolume: parseInt(el.energy_store_arr.amount),
              price: parseInt(el.energy_store_arr.price),
              sellerAddress: el.prosumer_obj['prosumer_address'],
              requiredEnergy: energyVal
            },
          };
        })
      );
      console.log("Coordinates for buyer--> ", locationPoints);
    }).finally(() => {
      setSearchLocationPoints(false);
    });
  };

  return (
    <>
      <BuyDetailsCard 
        onSearchEvent={ handleSearchEvent } 
        onEnergyVolumeChangeEvent = { handleEnergyVolumeChangeEvent }
        energyVolume = { energyVolume }
        searchLocationPoints={ searchLocationPoints }
      />
      <RenderMap 
        locationPoints={locationPoints}
      />
    </>
  );
};

export default BuyComponent;
