import React, { useContext, useState } from "react";
import Avatar from "@mui/material/Avatar";
import Stack from "@mui/material/Stack";
import { payTradingOrder } from "../services/services";
import { LoaderContext } from "./LoaderContext";
import { getDateFromTimestamp } from "../helpers/common";
import { Chip } from "@mui/material";
import { OrderStatus, handleColorCode } from "../constants/orderStatus";
import StatusDialog from "./StatusDialog";
import orderStatus from "../constants/dialogStatus";

const OrderHistoryUserCard = (props) => {
  const [openStatusDialog, setOpenStatusDialog] = useState(false);
  const [statusDialogContent, setStatusDialogContent] = useState({});

  const loader = useContext(LoaderContext);

  const handlePayment = () => {
    loader.setLoading(true);
    payTradingOrder(props.orderObj["order_id"])
      .then((data) => {
        console.log(
          "data return after pay button clicked in order history",
          data
        );
        setOpenStatusDialog(true);
        setStatusDialogContent(orderStatus.paymentSuccess);
      })
      .catch((error) => {
        console.log("payment failed -> ", error);
        setOpenStatusDialog(true);
        setStatusDialogContent(orderStatus.rejected);
      })
      .finally(() => {
        loader.setLoading(false);
      });
  };

  function handleCloseStatusDialogClick() {
    setOpenStatusDialog(false);
  }

  return (
    <div>
      <div className="card">
        <div className="card-body row orderHistoryCard">
          <div className="col-2">{props.orderObj["order_id"]}</div>
          <div className="col-2">
            {getDateFromTimestamp(props.orderObj["order_id"])}
          </div>
          <div
            className="col-2 d-flex gap-2 p-0"
            style={{ alignItems: "center" }}
          >
            <Stack direction="row" spacing={2}>
              <Avatar alt="Remy Sharp" src={props.orderObj.imageUrl} />
            </Stack>
            <p className="m-0">{props.orderObj.buyerName}</p>
          </div>
          <div className="col-2">{parseInt(props.orderObj["total_cost"])}$</div>
          <div className="col-2">
            {parseInt(props.orderObj["energy_amount"])}KWh
          </div>
          <div
            className="col-2 d-flex gap-3 align-items-center justify-content-center"
            style={{
              color:
                props.orderObj.status === 1
                  ? "red"
                  : handleColorCode(OrderStatus[props.orderObj.status]),
            }}
          >
            <Chip
              variant="filled"
              style={{
                color: "white",
                backgroundColor:
                  props.orderObj.status === 1
                    ? "red"
                    : handleColorCode(OrderStatus[props.orderObj.status]),
              }}
              label={OrderStatus[props.orderObj.status]}
            />

            {OrderStatus[props.orderObj.status] ===
              "Awaiting Payment" && (
              <button
                type="button"
                className="btn btn-outline-info btm-sm orderHistoryPayBtn"
                onClick={handlePayment}
                // style={{ border: "2px solid" }}
              >
                Pay
              </button>
            )}
          </div>
        </div>
      </div>
      <StatusDialog
        open={openStatusDialog}
        onDialogCloseEvent={handleCloseStatusDialogClick}
        content={statusDialogContent}
      />
    </div>
  );
};

export default OrderHistoryUserCard;
