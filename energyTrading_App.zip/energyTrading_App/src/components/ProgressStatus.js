import React, { useState } from "react";
// import PropTypes from "prop-types";
import Stack from "@mui/material/Stack";
import LinearProgress from "@mui/material/LinearProgress";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import CircularProgress from "@mui/material/CircularProgress";

const ProgressStatus = (props) => {
  return (
    <div
      className="my-3"
      style={{ width: "85%", textAlign: "center", color: "grey" }}
    >
      <div className="my-5">
        {/* <Box sx={{ position: "relative", display: "inline-flex" }}>
          <CircularProgress style={{width: "5rem", height:"5rem"}} variant="determinate" {...props} />
          <Box
            sx={{
              top: 0,
              left: 0,
              bottom: 0,
              right: 0,
              position: "absolute",
              display: "flex",
              alignItems: "center",
              justifyContent: "end",
            }}
          >
            <Typography
              variant="caption"
              component="div"
              color="text.secondary"
            >
              {`${Math.round(props.value)}%`}
            </Typography>
          </Box>
        </Box> */}
        <Stack sx={{ width: "100%", color: "grey.500" }} spacing={2}>
          <LinearProgress color="secondary" />
        </Stack>
        <div className="my-2">
          <span>Remaining Time : {props.value} sec</span>
        </div>
      </div>

      <div
        className="progress my-2"
        style={{ width: "100%", height: "1.4rem", margin: "auto" }}
      >
        <div
          className="progress-bar progress-bar-striped progress-bar-animated"
          role="progressbar"
          aria-valuenow="50"
          aria-valuemin="0"
          aria-valuemax="100"
          style={{ width: "70%" }}
        >
          {/* {props.value} */}
        </div>
      </div>

      <div>
        <span>Energy Transferred : {props.value} %</span>
      </div>
    </div>
  );
};

export default ProgressStatus;
