import React, { useState, useEffect } from "react";
import OrderHistoryUserCard from "./OrderHistoryUserCard";
import { getAllBuyOrders } from "../services/services";
import { OrderStatus } from "../constants/orderStatus";
import { CircularProgress, MenuItem } from "@mui/material";
import { FormControl, InputLabel, Select } from "@mui/material";

const OrderHistory = (props) => {
  const [orderHistoryData, setOrderHistoryData] = useState([]);
  const [selectedStatus, setSelectedStatus] = useState("All");
  const [orderHistoryLoading, setOrderHistoryLoading] = useState(false);

  useEffect(() => {
    setOrderHistoryLoading(true);
    const buyer_address = window.localStorage.getItem("accountAddr")
    getAllBuyOrders(buyer_address).then((data) => {
      console.log("return from getAllOrder for order history --> ", data);
      setOrderHistoryData(data.sort((a, b) => b.order_id - a.order_id));
    }).finally(() => {
      setOrderHistoryLoading(false);
    });
  }, []);

  function handleStatusChange(event) {
    setSelectedStatus(event.target.value);
  }

  function applyFilter() {
    if (selectedStatus === "All") return orderHistoryData;
    else {
      return orderHistoryData.filter(el => OrderStatus[el.status] === selectedStatus);
    }
  }

  return (
    <div className="orderHistoryContainer">
      <div className="d-flex justify-content-between mb-1 mr-1">
        <span className="orderHistoryHeadTitle">OrderHistory</span>
        <FormControl sx={{ m: 1, minWidth: 300 }}>
          <InputLabel id="select-status-label">Selected Status</InputLabel>
          <Select
            disabled={orderHistoryLoading}
            labelId="select-status-label"
            id="select-status"
            value={selectedStatus}
            label="Selected Status"
            onChange={handleStatusChange}
          >
            <MenuItem value="All" key="All">All</MenuItem>
            {
              OrderStatus.map(el => <MenuItem key={el} value={el}>{el}</MenuItem>)
            }
          </Select>
        </FormControl>
      </div>
      <div>
        {/* header part */}
        <nav
          className="navbar d-flex justify-content-center"
          style={{ backgroundColor: "#eb008c", height: "3.6rem" }}
        >
          <div className="card orderHistoryTitle">
            <div className="card-body row orderHistoryCard">
              <div className="col-2">Order Number</div>
              <div className="col-2">Date</div>
              <div className="col-2">Name</div>
              <div className="col-2">Cost</div>
              <div className="col-2">Energy</div>
              <div className="col-2" style={{ textAlign: "center" }}>Status</div>
            </div>
          </div>
        </nav>
        {/* body part */}
        <div className="orderHistoryCardMain">
          {
            !!orderHistoryLoading &&
            <div
              className="d-flex justify-content-center align-items-center"
            >
              <CircularProgress />
            </div>
          }
          {!orderHistoryLoading &&
            applyFilter().map((orderObjEle, index) => {
              const orderObj = {
                ...orderObjEle,
                buyerName: "Rohit Shukla",
                imageUrl: "https://i.pravatar.cc/300",
              };
              return <OrderHistoryUserCard key={index} orderObj={orderObj} />;
            })}
        </div>
      </div>
    </div>
  );
};

export default OrderHistory;
