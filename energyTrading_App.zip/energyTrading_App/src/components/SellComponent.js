import React from 'react';
import EnergyUserDetail from './EnergyUserDetail';
import EnergyOrder from './EnergyOrder';

const SellComponent = () => {
  return (
    <div className='container-fluid' style={{ width: "95%", marginBottom:"50px" }}>
      <div className='container-fluid row'>
        <div className='col-3 d-flex justify-content-center'>
          <EnergyUserDetail />
        </div>
        <div className='col-9'>
          <EnergyOrder />
        </div>
      </div>
    </div>
  );
}

export default SellComponent;
