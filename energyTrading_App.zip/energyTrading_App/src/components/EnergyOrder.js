import React, { useEffect, useState } from "react";
import OrderedEnergyCard from "./OrderedEnergyCard";
import { getAllSellOrders, getAllOrders } from "../services/services";
import CircularProgress from "@mui/material/CircularProgress";
import { FaExclamationTriangle } from "react-icons/fa";

const EnergyOrder = () => {
  const [buyerRequest, setBuyerRequest] = useState([]);
  const [buyerRequestLoading, setBuyerRequestLoading] = useState(false)
  useEffect(() => {
    setBuyerRequestLoading(true);
    const seller_address = window.localStorage.getItem("accountAddr");

    // getAllOrders().then((data) => {
    //   console.log("getAllOrder for seller page --> ", data);
    //   setBuyerRequest(data);
    // });

    getAllSellOrders(seller_address).then((data) => {
      console.log("getAllOrder for seller page --> ", data);
      setBuyerRequest(data.sort((a, b) => b.updationDate - a.updationDate));
    }).finally(() => {
      setBuyerRequestLoading(false);
    });
  }, []);

  return (
      <div className="card" style={{height: "100%"}}>
        {/* header part */}
        <nav
          className="navbar"
          style={{ backgroundColor: "#eb008c", height: "3.6rem" }}
        >
          <div className="container-fluid justify-content-center myOrderHeading">
            My Orders
          </div>
        </nav>

        {/* inside body part */}
        {
          !!buyerRequestLoading && 
          <div 
            className="card-body bg-light d-flex justify-content-center align-items-center"
          >
            <CircularProgress />
          </div>
        }
        {
          (!buyerRequestLoading && !buyerRequest.length) &&
          <div 
            className="card-body bg-light d-flex justify-content-center align-items-center"
          >
            <div className="d-flex flex-space-between-direction-column align-items-center">
              <FaExclamationTriangle color="orange" size="70"/>
              <span className="no-data-found-text">No Data found</span>
            </div>
          </div>
        }
        {
          (!buyerRequestLoading && !!buyerRequest.length) &&
          <div className="card-body mt-3 bg-light">
            {buyerRequest.map((buyerObj, index) => {
              const updatedBuyerObj = {
                ...buyerObj,
                buyerName: "Rohit Shukla",
                imageUrl: "https://i.pravatar.cc/300",
              };
              return <OrderedEnergyCard key={index} props={updatedBuyerObj} />;
            })}
          </div>
        }
      </div>
  );
};

export default EnergyOrder;