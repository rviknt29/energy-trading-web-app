import { Box, Button, Dialog } from "@mui/material";
import React from "react";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";

export default function StatusDialog(props) {
  const content = props.content;
  const handleClose = () => {
    props.onDialogCloseEvent();
  };

  return (
    <Dialog
      open={props.open}
      onClose={handleClose}
      aria-labelledby="dialog-title"
      maxWidth="sm"
      id="base-dialog"
      PaperProps={{
        sx: {
          paddingInline: "20px",
          paddingBottom: "10px",
          borderRadius: "24px",
        },
      }}
    >
      <DialogTitle
        className="dialog-title"
        sx={{
          fontStyle: "bold",
          fontSize: "2rem",
          lineHeight: "44.8px",
          textAlign: "center",
        }}
      >
        {!!content?.title && content.title}
      </DialogTitle>
      <DialogContent>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "space-between",
            rowGap: "5px",
            paddingInline: "10px",
            "& svg": {
              m: 1.5,
            },
            "& hr": {
              mx: 0.5,
            },
          }}
        >
          {content?.icon}
          <span className="base-dialog-description">{content?.subtitle}</span>
        </Box>
      </DialogContent>
      <DialogActions
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {/* Temprory commented to remove confirm/track payment */}

        {content.button && (
          <Button
            className="dialog-button dialog-button-filled"
            onClick={content.button.onClick}
          >
            Transfer Energy
          </Button>
        )}

        <Button
          className="dialog-button dialog-button-outlined"
          variant="outlined"
          onClick={handleClose}
        >
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
}
