import { Box, Dialog, IconButton } from "@mui/material";
import React from "react";
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import { FaRegTimesCircle } from 'react-icons/fa';

export default function BaseDialog(props) {
    let header;
    let actions;
    let content;
    
    React.Children.forEach(props.children, (child) => {
        if(!React.isValidElement(child)) return;
        if(child.type === BaseDialogHeader) {
            header = child;
        } else if(child.type === BaseDialogActions) {
            actions = child;
        } else {
            content = child;
        }
    });
  
    //const handleClickOpen = useCallback(() => setOpen(true), [props.open])
  
    const handleClose = () => {
      props.onDialogCloseEvent();
    };

    return (
      <Dialog
        open={props.open}
        onClose={handleClose}
        aria-labelledby="dialog-user-details-title"
        maxWidth="sm"
        PaperProps={{
          sx: {
            minWidth: "400px",
            paddingBottom: "10px",
            borderRadius: "24px"
        }}}
      >
        <DialogTitle id="dialog-user-details-title">
          <div style={{flex: "1", textAlign: "center"}}>
            {!!header && header}
          </div>
          <IconButton aria-label="close" size="small" color='inherit' onClick={handleClose}>
            <FaRegTimesCircle color="white"/>
          </IconButton>
        </DialogTitle>
        <DialogContent className='dialog-content'>
          <Box 
            sx={{
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                alignItems: 'center',
                rowGap: "5px",
                '& svg': {
                    m: 1.5,
                },
                '& hr': {
                    mx: 0.5,
                }
              }}
          >
            {!!content && content}
          </Box>
        </DialogContent>
        <DialogActions style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
          }}>
            {actions}
        </DialogActions>
      </Dialog>
    );
}

export function BaseDialogHeader(props) {
  return <>{props.children}</>;
}

export function BaseDialogActions(props) {
  return <>{props.children}</>;
}

export function BaseDialogContent(props) {
  return <>{props.children}</>
}