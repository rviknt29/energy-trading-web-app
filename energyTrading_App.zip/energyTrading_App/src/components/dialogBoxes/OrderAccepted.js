import React from "react";
import "./dialog.css";
import { CiCircleCheck } from "react-icons/ci";

const OrderAccepted = () => {
  return (
    <div>
      {/* Button trigger modal */}
      <button
        type="button"
        className="btn btn-primary"
        data-bs-toggle="modal"
        data-bs-target="#orderAcceptedModal"
      >
        Launch demo modal
      </button>

      {/* Modal  */}
      <div
        className="modal fade"
        id="orderAcceptedModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-centered">
          <div className="modal-content">
            <div className="modal-body orderAccepted d-flex gap-2 flex-column">
              <CiCircleCheck />
              <p>Your order got accepted !!</p>
              <button
                type="button"
                className="btn"
                data-bs-toggle="modal"
                data-bs-target="#successPaymentModal"
              >
                Pay Here
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* payment success modal */}
      <div
        className="modal fade"
        id="successPaymentModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-centered">
          <div className="modal-content">
            <div className="modal-body orderAccepted d-flex gap-2 flex-column">
              <h2 className="modal-title" id="paymentSuccessfulLabel">
                Payment Successful !
              </h2>
              <CiCircleCheck />
              <p>We have received your payment. Thanks!!</p>
              <div className="d-flex gap-4">
                <button type="button" className="btn">
                  Track Order
                </button>
                <button type="button" className="btn">
                  Back Home
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderAccepted;
