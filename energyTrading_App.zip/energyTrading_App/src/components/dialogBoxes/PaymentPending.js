import React from 'react';
import "./dialog.css";
import { CiCircleCheck } from "react-icons/ci";

const PaymentPending = () => {
  return (
    <div>
      {/* payment success modal */}
      <div
        className="modal fade"
        id="pendingPaymentModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-centered">
          <div className="modal-content">
            <div className="modal-body orderAccepted d-flex gap-2 flex-column">
              <h2 className="modal-title" id="paymentSuccessfulLabel">
                Payment Pending !
              </h2>
              <CiCircleCheck />
              <p>We have received your payment. Thanks!!</p>
              <div className="d-flex gap-4">
                <button type="button" className="btn">
                  Track Order
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PaymentPending;
