import Button from "@mui/material/Button";
import { Divider } from "@mui/material";
import IconButton from "@mui/material/IconButton";
import StatusDialog from "./StatusDialog";
import orderStatus from "../constants/dialogStatus";
import { useState, useContext } from "react";
import { FaCheckCircle } from "react-icons/fa";
import CertificateDialog from "./CertificateDialog";
import BaseDialog, { BaseDialogActions, BaseDialogContent } from "./BaseDialog";
import { placeTradingOrder } from "../services/services";
import { LoaderContext } from "./LoaderContext";

export default function BuyDetailsDialog(props) {
  const [openStatusDialog, setOpenStatusDialog] = useState(false);
  const [statusDialogContent, setStatusDialogContent] = useState({});
  const [openCertificateDialog, setOpenCertificateDialog] = useState(false);
  const loader = useContext(LoaderContext);

  function handlePlaceOrderClick() {
    loader.setLoading(true);
    // let accountAddr = "0x71bDad439e6C8E1Ffe470291FF79570E3e286813";
    let accountAddr = props.sellerInfo.sellerAddress;
    placeTradingOrder(props.sellerInfo.requiredEnergy, accountAddr)
      .then((orderedData) => {
        props.onDialogCloseEvent();
        console.log("after placing the order --> ", orderedData);
        setStatusDialogContent(orderStatus.accepted);
        setOpenStatusDialog(true);
      })
      .catch((error) => {
        console.log("Order failed with error -> ", error);
      })
      .finally(() => {
        loader.setLoading(false);
      });
    console.log(
      "order placed with ",
      props.sellerInfo.energyVolume,
      accountAddr,
      new Date().getTime()
    );
  }

  function handleOpenCertificateDialogClick() {
    props.onDialogCloseEvent();
    setOpenCertificateDialog(true);
  }

  function handlePayClick() {
    console.log("Pay here clicked");
  }

  function handleTrackOrderClick() {
    console.log("Track order clicked");
  }

  function handleRetryPaymentClick() {
    console.log("Retry payment clicked");
  }

  function handleCloseStatusDialogClick() {
    setOpenStatusDialog(false);
  }

  function handleCloseCertificateDialogClick() {
    setOpenCertificateDialog(false);
  }

  const handleClose = () => {
    props.onDialogCloseEvent();
  };

  const borderStyle = {
    opacity: 0.8,
    border: "1px solid rgba(0, 0, 0, 0.2)",
    marginInline: "0px !important",
  };

  return (
    <>
      <BaseDialog open={props.open} onDialogCloseEvent={handleClose}>
        <BaseDialogContent>
          <div
            className="flex-space-between"
            style={{
              gap: "50px",
              paddingInline: "15px",
              marginBlock: "8px 5px",
            }}
          >
            <div
              className="flex-space-between dialog-user-details"
              style={{ gap: "10px" }}
            >
              <img
                // src="https://res.cloudinary.com/dbfn5lnvx/image/upload/v1645464030/learnhtmlcss/images/cat.jpg"
                src="https://i.pravatar.cc/300"
                height="40px"
                width="40px"
                className="popup-avatar"
                alt="avatar"
              />
              <span>{props.sellerInfo?.name}</span>
            </div>
            <div className="flex-space-between" style={{ gap: "6px" }}>
              <span>Ecoable Energy</span>
              <IconButton
                size="small"
                onClick={handleOpenCertificateDialogClick}
              >
                <FaCheckCircle color="green" className="m-0" />
              </IconButton>
            </div>
          </div>
          <Divider flexItem sx={borderStyle} />
          <div className="dialog-cost-details">
            <div
              className="flex-space-between-direction-column"
              style={{ alignItems: "center" }}
            >
              <span className="dialog-cost-details-value">
                {props.sellerInfo?.energyVolume} KWh
              </span>
              <span className="dialog-cost-details-title">Energy</span>
            </div>
            <div
              className="flex-space-between-direction-column"
              style={{ alignItems: "center" }}
            >
              <span className="dialog-cost-details-value">
                {props.sellerInfo?.price} $
              </span>
              <span className="dialog-cost-details-title">Cost</span>
            </div>
          </div>
          <Divider flexItem sx={borderStyle} />
          <div
            className="dialog-user-contact-details"
            style={{ paddingInline: "15px" }}
          >
            <div>
              <span className="dialog-user-contact-details-title">
                Address:
              </span>
              <span> {props.sellerInfo?.location}</span>
            </div>
            <div>
              <span className="dialog-user-contact-details-title">
                Phone number:
              </span>
              <span> {props.sellerInfo?.phone}</span>
            </div>
            <div>
              <span className="dialog-user-contact-details-title">
                PinCode:
              </span>
              <span> 411001</span>
            </div>
            <div>
              <span className="dialog-user-contact-details-title">Email:</span>
              <span> xyz@greenenergy.com</span>
            </div>
          </div>
        </BaseDialogContent>
        <BaseDialogActions>
          <Button
            className="dialog-button dialog-button-filled"
            onClick={handlePlaceOrderClick}
          >
            Place Order
          </Button>
        </BaseDialogActions>
      </BaseDialog>

      <StatusDialog
        open={openStatusDialog}
        onDialogCloseEvent={handleCloseStatusDialogClick}
        content={statusDialogContent}
      />
      <CertificateDialog
        open={openCertificateDialog}
        onDialogCloseEvent={handleCloseCertificateDialogClick}
      />
    </>
  );
}
