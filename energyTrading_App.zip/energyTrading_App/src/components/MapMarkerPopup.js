import { Popup } from "react-leaflet";
import BuyDetailsDialog from "./BuyDetailsDialog";
import { useState } from "react";

export default function MapMarkerPopup(props) {
  const [openDialog, setOpenDialog] = useState(false);

  function handleOpenDialogClick() {
    setOpenDialog(true);
  }

  function handleCloseDialogClick() {
    setOpenDialog(false);
  }

  return (
    <>
      <div
        style={{ maxwidth: "1500px" }}
        onClick={handleOpenDialogClick}
        className="map-popup"
      >
        <Popup>
          <div className="row g-0">
            <div className="col-4">
              <img
                // src="https://res.cloudinary.com/dbfn5lnvx/image/upload/v1645464030/learnhtmlcss/images/cat.jpg"
                src="https://i.pravatar.cc/300"
                height="42"
                width="42"
                className="popup-avatar"
                alt="avatar"
              />
            </div>
            <div className="col-8 popup-details text-left">
              <div
                className="user-name"
                style={{ fontSize: "1rem", fontWeight: "600" }}
              >
                {props.sellerInfo?.name}
              </div>
              <div className="cost-details">
                <div>{props.sellerInfo?.price} $</div>
                <div>{props.sellerInfo?.energyVolume} Kwh</div>
              </div>
            </div>
          </div>
        </Popup>
      </div>
      <BuyDetailsDialog
        open={openDialog}
        onDialogCloseEvent={handleCloseDialogClick}
        sellerInfo={props.sellerInfo}
      />
    </>
  );
}
