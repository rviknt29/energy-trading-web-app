import { MapContainer, TileLayer, Marker, useMap } from "react-leaflet";
import { useEffect } from "react";
import MapMarkerPopup from "./MapMarkerPopup";

export default function RenderMap(props) {
  function FlyMapTo() {
    const map = useMap();
    useEffect(() => {
      if (props.locationPoints.length)
        map.flyTo(props.locationPoints[0]["cordinates"]);
      // map.flyTo(props.locationPoints[7]["cordinates"]);
    }, [props.locationPoints]);

    return null;
  }

  return (
    <>
      <div id="map">
        <MapContainer
          center={[18.559, 73.7868]}
          zoom={13}
          scrollWheelZoom={false}
        >
          <TileLayer
            attribution='&amp;copy <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.osm.org/{z}/{x}/{y}.png"
          />

          {props.locationPoints.length &&
            props.locationPoints.map((el, index) => {
              return (
                <Marker key={index} position={el.cordinates}>
                  <MapMarkerPopup sellerInfo={el.sellerInfo} />
                </Marker>
              );
            })}

          <FlyMapTo />
        </MapContainer>
      </div>
    </>
  );
}
