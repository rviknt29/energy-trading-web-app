import React from "react";
import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";

const steps = ["Pending", "Completed"];

const StepperComponent = ({ currentStatus }) => {
  const getLabelProps = (index) => {
    const isActive = currentStatus === steps[index].toLowerCase();
    const color = isActive
      ? currentStatus === "pending"
        ? "red"
        : "green"
      : "gray";
    return {
      active: isActive,
      completed: isActive,
      optional: !isActive,
      error: isActive,
      style: { color },
    };
  };

  return (
    <Box sx={{ width: "100%", marginTop:"2rem" }}>
      <Stepper
        activeStep={currentStatus === "pending" ? 1 : 0}
        alternativeLabel
      >
        {steps.map((label, index) => (
          <Step key={label}>
            <StepLabel {...getLabelProps(index)}>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
    </Box>
  );
};

export default StepperComponent;
