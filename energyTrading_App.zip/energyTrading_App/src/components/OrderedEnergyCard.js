import React, { useEffect, useState, useContext } from "react";
import ReactDOM from "react-dom";
import Avatar from "@mui/material/Avatar";
import Stack from "@mui/material/Stack";
import { RxCross2 } from "react-icons/rx";
import { FiClock } from "react-icons/fi";
import { GiHourglass } from "react-icons/gi";
import { FaExclamationCircle } from "react-icons/fa";
import { IoIosCheckmarkCircle } from "react-icons/io";
import { IoIosSync } from "react-icons/io";
import { BsExclamationTriangle } from "react-icons/bs";
import "./dialogBoxes/dialog.css";
import StepperComponent from "./StepperComponent";
import StatusDialog from "./StatusDialog";
import orderStatus from "../constants/dialogStatus";
import { LoaderContext } from "./LoaderContext";
import {
  acceptedOrRejectTradingOrder,
  transferInitiatedOrder,
} from "../services/services";
import BaseDialog, {
  BaseDialogActions,
  BaseDialogContent,
  BaseDialogHeader,
} from "./BaseDialog";
import Button from "@mui/material/Button";
import ProgressStatus from "./ProgressStatus";

const OrderedEnergyCard = ({ props }) => {
  const [rejected, setRejected] = useState(false);
  const [accepted, setAccepted] = useState(false);
  const [openStatusDialog, setOpenStatusDialog] = useState(false);
  const [openTransitDialog, setOpenTransitDialog] = useState(false);
  const [statusDialogContent, setStatusDialogContent] = useState({});
  const [progress, setProgress] = useState(10);

  useEffect(() => {
    props.status === 1
      ? setRejected(true)
      : props.status !== 0
      ? setAccepted(true)
      : setAccepted(false);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prevProgress) =>
        prevProgress >= 100 ? 10 : prevProgress + 10
      );
    }, 800);
    return () => {
      clearInterval(timer);
    };
  }, []);

  const loader = useContext(LoaderContext);

  const handleStatusTitle = (status) => {
    const statusTitle = {
      0: "Pending Order",
      1: "Order Rejected",
      2: "Order Accepted, Awaiting Payment",
      3: "Error Payment", //paymentFailed
      4: "Payment Success", //paymentSuccess
      5: "In Transit", //inTransit
      6: "Completed", //transferCompleted
      7: "Error Transit", //transitError
    };
    return statusTitle[status] || ""; // Return an empty string if the status is not found
  };

  const handleStatusSubTitle = (status) => {
    const statusSubTitle = {
      0: "Pending Order",
      1: "Order Rejected",
      2: "Payment pending from buyer...",
      3: "Issue in payment...",
      4: "Ready to transfer energy...",
      5: "Energy transaction in progress...",
      6: "Energy transfer completed !!",
      7: "Error in energy transaction !!",
    };
    return statusSubTitle[status] || ""; // Return an empty string if the status is not found
  };

  const handleStatusSymbol = (status) => {
    switch (status) {
      case 2:
        return <GiHourglass style={{ color: "orange" }} />;
      case 3:
        return <FaExclamationCircle style={{ color: "red" }} />;
      case 4:
        return <IoIosCheckmarkCircle style={{ color: "green" }} />;
      case 5:
        return <IoIosSync style={{ color: "blue" }} />;
      case 6:
        return <IoIosCheckmarkCircle style={{ color: "green" }} />;
      case 7:
        return <BsExclamationTriangle style={{ color: "red" }} />;
      default:
        return <FiClock style={{ color: "black" }} />;
    }
  };

  const handleDialogContent = (status) => {
    switch (status) {
      case 2:
        setStatusDialogContent(orderStatus.pendingOrder);
        break;
      case 3:
        setStatusDialogContent(orderStatus.paymentFailed);
        break;
      case 4:
        orderStatus.paymentSuccess.button = {
          onClick: handleTransit,
          label: "Pay Here",
        };
        setStatusDialogContent(orderStatus.paymentSuccess);
        break;
      case 5:
        setStatusDialogContent(orderStatus.inTransit);
        break;
      case 6:
        setStatusDialogContent(orderStatus.transferCompleted);
        break;
      case 7:
        setStatusDialogContent(orderStatus.transitError);
        break;
      default:
        setStatusDialogContent(orderStatus.transitError);
        break;
    }
  };

  const handleReject = () => {
    loader.setLoading(true);
    acceptedOrRejectTradingOrder(props.order_id, false)
      .then((data) => {
        console.log("value retured after reject button clicked ->", data);
        setRejected(true);
        setOpenStatusDialog(true);
        setStatusDialogContent(orderStatus.rejected);
      })
      .finally(() => {
        loader.setLoading(false);
      });
  };

  const handleAccept = () => {
    loader.setLoading(true);
    acceptedOrRejectTradingOrder(props.order_id, true)
      .then((data) => {
        console.log("value retured after accept button clicked ->", data);
        setAccepted(true);
        setOpenStatusDialog(true);
        setStatusDialogContent(orderStatus.orderAccepted);
      })
      .catch((error) => {
        console.error("Error accepting order:", error);
      })
      .finally(() => {
        loader.setLoading(false);
      });
  };

  // This fucntion will be called on transfer button clicked
  const handleTransit = () => {
    loader.setLoading(true);
    setAccepted(true);
    setOpenStatusDialog(false);
    setOpenTransitDialog(true);
    transferInitiatedOrder(props.order_id)
      .then((data) => {
        console.log("value retured after transfer button clicked ->", data);
        setAccepted(true);
        setOpenTransitDialog(true);
      })
      .catch((error) => {
        console.log(error);
        setAccepted(true);
        setOpenTransitDialog(true);
      })
      .finally(() => {
        loader.setLoading(false);
      });
  };

  const handleOrderTrack = () => {
    console.log("current status ----> ", props.status);
    setOpenStatusDialog(true);
    // setStatusDialogContent(orderStatus.transferCompleted);
    handleDialogContent(props.status);

    // var targetModal = document.getElementById("successPaymentModal2");
    // var modalTitle = targetModal.querySelector(".modal-title");
    // var modalSubTitle = targetModal.querySelector(".modal-sub-title");
    // var statusSymbol = targetModal.querySelector(".statusSymbol");
    // console.log("track order button clicked", props.status);
    // modalTitle.textContent = handleStatusTitle(props.status);
    // modalSubTitle.textContent = handleStatusSubTitle(props.status);

    // // Clear the content of statusSymbol first
    // while (statusSymbol.firstChild) {
    //   statusSymbol.removeChild(statusSymbol.firstChild);
    // }
    // const symbol = handleStatusSymbol(props.status);
    // const symbolWrapper = document.createElement("span");
    // ReactDOM.render(symbol, symbolWrapper);
    // statusSymbol.appendChild(symbolWrapper);

    // props.status === 4
    //   ? (targetModal.querySelector(".energyBtnTransfer").style.display = "flex")
    //   : (targetModal.querySelector(".energyBtnTransfer").style.display =
    //       "none");
  };

  function handleCloseStatusDialogClick() {
    setOpenStatusDialog(false);
  }

  function handleCloseTransitDialogClick() {
    setOpenTransitDialog(false);
  }

  return (
    <div className="gh">
      <div className="card carEnergyRow my-4">
        <div className="card-body row">
          <div className="col-6 d-flex gap-3">
            <div>
              <Stack direction="row" spacing={2}>
                <Avatar alt="Remy Sharp" src={props.imageUrl} />
              </Stack>
            </div>
            <div>
              <div>{props.buyerName}</div>
              <div className="d-flex gap-3" style={{ height: "1rem" }}>
                <p>{parseInt(props.energy_amount)} KWh</p>
                <p>{parseInt(props.total_cost)} $</p>
              </div>
            </div>
          </div>
          {rejected ? (
            <div className="col-6 d-flex justify-content-end">
              <button
                type="button"
                className="btn btn-outline-primary d-flex align-content-center gap-1"
                style={{
                  marginRight: "2.5rem",
                  alignItems: "center",
                  color: "red",
                  border: "2px solid",
                }}
              >
                <RxCross2 />
                Rejected
              </button>
            </div>
          ) : accepted ? (
            <div className="col-6 d-flex justify-content-end">
              <button
                type="button"
                className="btn btn-outline-primary d-flex align-content-center gap-1"
                style={{ marginRight: "2.2rem", alignItems: "center" }}
                // data-bs-toggle="modal"
                // data-bs-target="#successPaymentModal2"
                onClick={handleOrderTrack}
              >
                Track Status
              </button>
            </div>
          ) : (
            <div className="col-6 d-flex justify-content-end gap-3">
              <button
                type="button"
                className="btn btn-outline-primary"
                onClick={handleAccept}
                // data-bs-toggle="modal"
                // data-bs-target= {openPopup ? "#pendingPaymentModal" : ""}
                // data-bs-target="#pendingPaymentModal"
                style={{ color: "green", border: "2px solid" }}
              >
                Accept
              </button>
              <button
                type="button"
                className="btn btn-outline-primary"
                style={{ color: "red", border: "2px solid" }}
                onClick={handleReject}
              >
                Reject
              </button>
            </div>
          )}
        </div>
      </div>

      {/* payment pending modal -starts */}
      <StatusDialog
        open={openStatusDialog}
        onDialogCloseEvent={handleCloseStatusDialogClick}
        content={statusDialogContent}
      />
      {/* Payment pending modal - end */}

      {/* payment successful modal -starts */}
      {/* <div
        className="modal fade"
        id="successPaymentModal2"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-centered">
          <div className="modal-content">
            <div className="modal-body orderAccepted d-flex gap-2 flex-column">
              <h2 className="modal-title" id="paymentSuccessfulLabel2"></h2>
              <div className="statusSymbol"></div>
              <p className="modal-sub-title"></p>
              <div className="d-flex gap-4">
                <button
                  type="button"
                  className="btn energyBtnTransfer"
                  onClick={handleTransit}
                  data-bs-dismiss="modal"
                >
                  Transfer
                </button>
              </div>
            </div>
          </div>
        </div>
      </div> */}
      {/* payment successful modal -ends */}

      {/* In transit modal - starts */}
      <BaseDialog
        open={openTransitDialog}
        onDialogCloseEvent={handleCloseTransitDialogClick}
      >
        <BaseDialogHeader style={{ textAlign: "center" }}>
          In Transit
        </BaseDialogHeader>
        <BaseDialogContent style={{ padding: "0" }}>
          {/* <StepperComponent currentStatus="success" /> */}
          <ProgressStatus value={progress} />
        </BaseDialogContent>
        <BaseDialogActions>
          <Button
            type="button"
            className="dialog-button dialog-button-filled"
            onClick={handleCloseTransitDialogClick}
          >
            Back
          </Button>
        </BaseDialogActions>
      </BaseDialog>
      {/* In transit modal - ends */}
    </div>
  );
};

export default OrderedEnergyCard;
