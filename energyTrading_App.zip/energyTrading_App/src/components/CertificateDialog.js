import { Divider } from "@mui/material";
import BaseDialog, { BaseDialogActions, BaseDialogContent } from "./BaseDialog";
import { FaRegUser } from "react-icons/fa";
import { useState } from "react";
import { magentaTrustABI } from "../services/constants";
import { ethers } from "ethers";
import { useEffect } from "react";

export default function CertificateDialog(props) {
  const [result, setResult] = useState(false);
  const [issuerName, setIssuerName] = useState("");
  const [firstLinkUrl, setFirstLinkUrl] = useState("");

  useEffect(() => {
    getDetails();
    console.log("use effect called on certificate page");
  }, []);

  const borderStyle = {
    opacity: 0.8,
    border: "1px solid rgba(0, 0, 0, 0.2)",
    marginInline: "0px !important",
  };

  const getDetails = async () => {
    const docID = "bafybeifbjm7ilkbmzgz7so6cnc5e6k5bkaetmvraz5umredbodvh7xc5qa";
    // console.log("bafybeieezzo4zre7fujal7wn5ndzzyefsfizb6e3sjtc7k4c57sxtho7ru"); //url for fraud document

    const qrDetails = await parseURL(
      "https://ipfs.io/ipfs/" + docID + "/magenta-qr.json"
    );

    console.log(qrDetails.certificateCID);
    console.log(qrDetails.merkleLeaf);
    console.log(qrDetails.merkleProof);
    console.log(qrDetails.tx); // it will be converted to link-1

    const certificateDetails = await parseURL(
      "https://ipfs.io/ipfs/" + qrDetails.certificateCID + "/certificate.json"
    );

    // setFirstLinkUrl("https://mumbai.polygonscan.com/tx/" + qrDetails.tx);
    setFirstLinkUrl("https://magentatrust.vercel.app/verification/" + docID);

    console.log(certificateDetails);
    setIssuerName(certificateDetails.issuerName);
    // setIssuedTime(certificateDetails.timeStamp);
    // setIssuerAddress(certificateDetails.issuerAddress);
    // setIssuedTo(certificateDetails.issuedTo);
  };

  const handleVerification = async () => {
    console.log(window.location.href);
    const url = window.location.href;
    const docID = url.slice(35);
    // console.log("bafybeieezzo4zre7fujal7wn5ndzzyefsfizb6e3sjtc7k4c57sxtho7ru");

    const qrDetails = await parseURL(
      "https://ipfs.io/ipfs/" + docID + "/magenta-qr.json"
    );

    console.log(qrDetails.certificateCID);
    console.log(qrDetails.merkleLeaf);
    console.log(qrDetails.merkleProof);
    console.log(qrDetails.tx);

    const provider = new ethers.providers.JsonRpcProvider(
      "https://matic-mumbai.chainstacklabs.com"
    );

    const magentaTrust = new ethers.Contract(
      "0xd94516445b4254cF456cB697C56cdaE91C78840a",
      magentaTrustABI,
      provider
    );

    const docHash = qrDetails.merkleLeaf;
    const merkleProof = qrDetails.merkleProof;
    const result = await magentaTrust.validateDocument(docHash, merkleProof);
    console.log(result);
    setResult(result);
  };

  const parseURL = async (url) => {
    const data = await fetch(url);
    console.log(data);
    const json = await data.json();
    console.log(json);
    return json;
  };

  return (
    <>
      <BaseDialog {...props}>
        <BaseDialogContent>
          <FaRegUser size="85" style={{ color: "grey" }} />
          <div style={{ fontWeight: "bold" }}>
            <span className="dialog-user-contact-details-title mx-2">
              Issuer Name:
            </span>
            <span style={{ color: "green" }}>Magenta Trust</span>
          </div>
          <Divider flexItem sx={borderStyle} />
        </BaseDialogContent>
        <BaseDialogActions>
          <div
            className="d-flex justify-content-center"
            style={{ gap: "25px" }}
          >
            <a
              className="certficate-dialog-link"
              href={firstLinkUrl}
              target="_blank"
            >
              Magenta Trust Verification Link
            </a>
          </div>
        </BaseDialogActions>
      </BaseDialog>
    </>
  );
}
