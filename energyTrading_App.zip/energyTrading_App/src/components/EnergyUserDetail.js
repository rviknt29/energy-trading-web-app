import React, { useEffect, useState } from "react";
import Avatar from "@mui/material/Avatar";
import Stack from "@mui/material/Stack";
import getProsumersInfo from "../services/services";
import { Chip } from "@mui/material";
import { FaBolt } from "react-icons/fa";

const EnergyUserDetail = () => {
  const [sellerInfo, setSellerInfo] = useState({
    sellerName: "Ravi",
    sellerLocation: "Marunji, Hinjewadi",
    sellerPhoneNum: 2035647867
  });
  // useEffect for getting seller details - buyer can also be seller or vice versa - hence as of now buyer & seller details is same
  useEffect(() => {
    getProsumersInfo().then((sellerInfo) => {
      console.log("sellerInfo", sellerInfo);
      setSellerInfo({
        sellerName: sellerInfo["prosumer_obj"]["name"],
        sellerLocation: sellerInfo["prosumer_obj"]["location"],
        sellerPhoneNum: sellerInfo["prosumer_obj"]["phone"]
      });
    });
  }, []);

  return (
    <div style={{ height: "100%" }}>
      <div className="card" style={{ width: "21rem", height: "100%" }}>
        <nav className="navbar" style={{ backgroundColor: "#eb008c" }}>
          <div className="container-fluid">
            <Stack direction="row" spacing={2}>
              <Avatar alt="Remy Sharp" src="./images/gentleman.jpg" />
            </Stack>
          </div>
        </nav>
        <div className="card-body my-3 bg-light d-flex flex-column justify-content-around">
          <div className="mb-3">
            <div className="d-flex justify-content-between py-2">
              <span className="energy-user-details-title">Name:</span>
              <span className="energy-user-details">{sellerInfo.sellerName}</span>
            </div>
            <div className="d-flex justify-content-between py-2">
              <span className="energy-user-details-title">Phone Number:</span>
              <span className="energy-user-details">{sellerInfo.sellerPhoneNum}</span>
            </div>
            <div className="d-flex justify-content-between py-2">
              <span className="energy-user-details-title">Email Id:</span>
              <span className="energy-user-details">xyz@greenenergy.com</span>
            </div>
          </div>
          <hr className="my-1" />
          <div className="my-3">
            <div
              className="d-flex justify-content-center mb-4"
              style={{
                fontSize: "1.25rem",
                lineHeight: "25.2px",
                fontWeight: "700"
              }}
            >Energy Type</div>
            <Chip
              className="my-0"
              label="Electric"
              variant="filled"
              icon={<FaBolt />}
              color="info"
              sx={{
                fontSize: "1rem",
                width: "100%"
              }}
            />
          </div>
          <div className="mt-5 flex-grow-1 d-flex align-items-end">
            <span className="energy-user-details-title">Joined: </span>
            <span className="energy-user-details">13/05/2023</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EnergyUserDetail;
