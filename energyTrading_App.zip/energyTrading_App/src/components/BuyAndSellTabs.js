import React, { useContext } from "react";
import PropTypes from "prop-types";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import BuyComponent from "./BuyComponent";
import SellComponent from "./SellComponent";
import Avatar from "@mui/material/Avatar";
import Stack from "@mui/material/Stack";
import { styled } from "@mui/material/styles";
import Tooltip, { tooltipClasses } from "@mui/material/Tooltip";
import OrderHistory from "./OrderHistory";
// import { getAllOrders } from "../services/services";
import { LoaderContext } from "./LoaderContext";
import OverlayLoader from "./OverlayLoader";
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

const HtmlTooltip = styled(({ className, ...props }) => (
  <Tooltip
    {...props}
    classes={{ popper: className }}
    arrow
    leaveTouchDelay={5000}
  />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: "#eb008c",
    color: "#fff",
    maxWidth: 220,
    border: "1px solid #dadde9",
    cursor: "pointer",
  },
}));

const BuyAndSellTabs = () => {
  const [value, setValue] = React.useState(0);
  // const [showHistory, setShowHistory] = useState(false);
  // const [showHistoryTooltip, setShowHistoryTooltip] = useState(false);
  // const [orderHistoryData, setOrderHistoryData] = useState([]);
  const loader = useContext(LoaderContext);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const handleLogout = () => {
    window.location.href = "/";
  };

  // const handleHistoryTab = () => {
  //   setShowHistory(!showHistory);
  //   setShowHistoryTooltip(!showHistoryTooltip);

  //   getAllOrders().then((data) => {
  //     console.log("return from getAllOrder for order history --> ", data);
  //     setOrderHistoryData(data);
  //   });
  // };

  return (
    <>
      {loader.loading && <OverlayLoader />}
      <Box sx={{ width: "100%" }}>
        <Box
          sx={{ borderBottom: 1, borderColor: "divider" }}
          className="d-flex justify-content-between align-content-center mx-5 my-3 border-0"
        >
          <div className="ecoable">ECOABLE</div>
          <Tabs
            value={value}
            onChange={handleChange}
            aria-label="basic tabs example"
            className="buy-sell-tab"
          >
            {/* {value !== 0 ? (
              <Tab label="Buy" {...a11yProps(0)} />
            ) : (
              <HtmlTooltip
                title={
                  <div
                    className="buyCompTooltip"
                    style={{ height: "1.5rem" }}
                    onClick={handleBuyTab}
                  >
                    <p style={{ fontSize: "1rem" }}>
                      {showHistoryTooltip
                        ? "Visit Buy Screen"
                        : "Order History"}
                    </p>
                  </div>
                }
              >
                <Tab label="Buy" {...a11yProps(0)} />
              </HtmlTooltip>
            )} */}

            <Tab label="Buy" {...a11yProps(0)} />

            <Tab label="Sell" {...a11yProps(1)} />

            <Tab label="Order History" {...a11yProps(2)} />

            <HtmlTooltip
              title={
                <div
                  className="d-flex justify-content-center align-content-center gap-1"
                  style={{ height: "1.5rem" }}
                  onClick={handleLogout}
                >
                  <img
                    src="./images/icons-logout.png"
                    alt="img"
                    style={{ height: "1.4rem" }}
                    className="d-flex justify-content-center align-content-center"
                  />
                  <p style={{ fontSize: "1rem" }}>Logout</p>
                </div>
              }
            >
              <Stack direction="row" spacing={2}>
                <Avatar alt="Remy Sharp" src="https://i.pravatar.cc/300" />
              </Stack>
            </HtmlTooltip>
          </Tabs>
        </Box>
        {/* <TabPanel value={value} index={0} className="buy_order_section">
          {showHistory ? (
            <OrderHistory orderHistoryData={orderHistoryData} />
          ) : (
            <BuyComponent />
          )}
        </TabPanel> */}
        <TabPanel value={value} index={0}>
          <BuyComponent />
        </TabPanel>
        <TabPanel value={value} index={1}>
          <SellComponent />
        </TabPanel>
        <TabPanel value={value} index={2} >
          <OrderHistory />
        </TabPanel>
      </Box>
      {/* Footer section */}
      {value !== 0 && (
        <nav className="navbar fixed-bottom footerMain">
          <div className="container-fluid row">
            <div className="col-7 d-flex justify-content-end">
              <p>©2023 ECOABLE. All Rights Reserved</p>
            </div>
            <div className="col-5 d-flex gap-4 justify-content-end">
              <p>Terms & Conditions</p>
              <p>Privacy</p>
              <p>Cookies</p>
            </div>
          </div>
        </nav>
      )}
    </>
  );
};

export default BuyAndSellTabs;
