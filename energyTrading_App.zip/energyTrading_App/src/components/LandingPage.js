import React, { useEffect, useState, useContext } from "react";
import { useNavigate } from "react-router";
import OverlayLoader from "./OverlayLoader";
import { LoaderContext } from "./LoaderContext";

const LandingPage = () => {
  // const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
  const [defaultAccount, setDefaultAccount] = useState(null);
  const loader = useContext(LoaderContext);

  useEffect(() => {
    checkWalletIsConnected();
  }, []);

  const navigate = useNavigate();

  const checkWalletIsConnected = async () => {
    const { ethereum } = window;
    if (!ethereum || window.localStorage.getItem("accountAddr") === null) {
      console.log("Make sure you have metamask!");
      return;
    } else {
      console.log("We have the ethereum object", ethereum);
    }

    ethereum.request({ method: "eth_accounts" }).then((accounts) => {
      if (accounts.length !== 0) {
        const account = accounts[0];
        console.log("Found an account:", account);
        window.localStorage.setItem("accountAddr", account);

        setDefaultAccount(account);
        console.log("defaultAccount: ", defaultAccount);
      } else {
        console.log("No account found");
      }
    });
  };


  const connectwalletHandler = () => {
    loader.setLoading(true);
    const { ethereum } = window;
    if (!ethereum) {
      alert("Get MetaMask!");
      return;
    }
    ethereum
      .request({ method: "eth_requestAccounts" })
      .then((accounts) => {
        console.log("Connected", accounts[0]);
        setDefaultAccount(accounts[0]);
        console.log("defaultAccount in connectwalletHandler: ", defaultAccount);
        window.localStorage.setItem("accountAddr", accounts[0]);

        navigate('/buyandsell');
      })
      .catch((err) => {
        console.log(err)
      }).finally(() => {
        loader.setLoading(false);
      });
    console.log("Required Address --> ", defaultAccount);
  };

  // const accountChangedHandler = async (newAccount) => {
  //   const address = await newAccount.getAddress();
  //   console.log("Address from metamask --> ", address);
  //   setDefaultAccount(address);
  //   console.log("required address2 -> ", defaultAccount);
  // };

  return (
    <div>
      {loader.loading && <OverlayLoader />}
      <nav className="navbar navbar-expand-lg">
        <div className="container-fluid">
          <a className="navbar-brand navbar-ecoable" href="/">
            ECOABLE
          </a>
          <div
            className="collapse navbar-collapse justify-content-end"
            id="navbarTogglerDemo03"
          >
            <ul
              className="navbar-nav mb-2 mb-lg-0 gap-3"
              style={{ alignItems: "center" }}
            >
              <li className="nav-item">
                <a className="nav-link active" aria-current="page" href="/">
                  Home
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link active" href="/">
                  About Us
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link active" href="/">
                  Services
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link p-0">
                  <button
                    type="button"
                    className="btn connectBtn d-flex justify-content-center align-content-center"
                    onClick={connectwalletHandler}
                  >
                    Connect Wallet
                  </button>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      {/* Body section */}
      <div className="container-fluid p-0">
        <div className="landingPage-image-section">
          {/* <h1>A GREEN FUTURE</h1>
          <h4>
            "We are commited to build our planet greener and sustainable in
            future"
          </h4> */}
        </div>
        <div className="feature-section p-4">
          <div className="mb-4">
            <h3>FEATURES AND BENEFITS</h3>
          </div>
          <div className="featureBenefits d-flex justify-content-evenly">
            <div className="card" style={{ width: "18rem" }}>
              <div className="card-body">
                <img src="./images/IoT.png" alt="energy-icon" />
                <h5 className="card-title">Blockchain plus IOT</h5>
                <p className="card-text">
                  We provide mixture of technologies like blockchain as well as
                  Internet of Things to enhance our services.
                </p>
              </div>
            </div>

            <div className="card" style={{ width: "18rem" }}>
              <div className="card-body">
                <img src="./images/blockchain.png" alt="energy-icon" />
                <h5 className="card-title">Blockhain</h5>
                <p className="card-text">
                  Blockchain helps to facilitate a sense of trust among our
                  users.
                </p>
              </div>
            </div>

            <div className="card" style={{ width: "18rem" }}>
              <div className="card-body">
                <img src="./images/energy.png" alt="energy-icon" />
                <h5 className="card-title">Energy</h5>
                <p className="card-text">
                  Energy producers allows to set their own pricing scheme and
                  not violating the law of land.
                </p>
              </div>
            </div>

            <div className="card" style={{ width: "18rem" }}>
              <div className="card-body">
                <img src="./images/smartContract.png" alt="energy-icon" />
                <h5 className="card-title">Smart Contracts</h5>
                <p className="card-text">
                  IoT Devices plus Blockchain smart contracts would enable
                  smooth tracking of energy supply leading towards trustworthy
                  data and corresponding.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer section */}
      {/* fixed-bottom removed temprory */}
      <nav className="navbar footerMain">
        <div className="container-fluid row">
          {/* <a className="navbar-brand" style={{ color: "#fff" }} href="#">
          ©2023 ECOABLE. All Rights Reserved
          </a> */}
          <div className="col-7 d-flex justify-content-end">
            <p>©2023 ECOABLE. All Rights Reserved</p>
          </div>
          <div className="col-5 d-flex gap-4 justify-content-end">
            <p>Terms & Conditions</p>
            <p>Privacy</p>
            <p>Cookies</p>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default LandingPage;
