import { CircularProgress } from "@mui/material";

export default function OverlayLoader() {
    return (
        <div className="d-flex justify-content-center 
        align-items-center 
        flex-column
        landing-page-loader
        landing-scaffold overlay">
            <CircularProgress />
        </div>
    );
}