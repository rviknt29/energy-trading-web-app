import { FaRegUserCircle, FaMapMarkerAlt } from "react-icons/fa";
import Box from "@mui/material/Box";
import Divider from "@mui/material/Divider";
import Chip from "@mui/material/Chip";
import Stack from "@mui/material/Stack";
import CircularProgress from "@mui/material/CircularProgress";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import { useEffect, useState } from "react";
import getProsumersInfo from "../services/services";
import { green } from "@mui/material/colors";

export default function BuyDetailsCard(props) {
  const [buyerInfo, setBuyerInfo] = useState({
    buyerName: "Ravi",
    buyerLocation: "Marunji, Hinjewadi",
  });

  // useEffect for getting buyer details
  useEffect(() => {
    getProsumersInfo().then((address) => {
      setBuyerInfo({
        buyerName: address["prosumer_obj"]["name"],
        buyerLocation: address["prosumer_obj"]["location"],
      });
    });
  }, []);

  const borderStyle = {
    bgcolor: "white",
    opacity: 1,
    width: "1.5px",
    marginInline: "0px !important",
  };

  const textFieldStyle = {
    "& .MuiOutlinedInput-root": {
      "&.Mui-focused fieldset": {
        borderColor: "transparent",
      },
      "&:hover fieldset": {
        borderColor: "transparent",
      },
      "& fieldset": {
        borderColor: "transparent",
      },
    },
  };

  return (
    <>
      <Box
        className="buy-details-card"
        sx={{
          display: "flex",
          alignItems: "center",
          width: "fit-content",
          border: (theme) => `1px solid ${theme.palette.divider}`,
          borderRadius: 2,
          bgcolor: "#E20074",
          color: "white",
          "& svg": {
            m: 1.5,
          },
          "& hr": {
            mx: 0.5,
          },
        }}
      >
        {buyerInfo.buyerName === "Ravi" ? (
          <div>
            <Stack
              sx={{ color: "white", alignItems: "center" }}
              spacing={2}
              direction="column"
            >
              <CircularProgress
                color="success"
                style={{ width: "60px", height: "60px", color: "white" }}
              />
              <p>Loading Buyer Details...</p>
            </Stack>
          </div>
        ) : (
          <div className="buy-card-user-details">
            <img
              // src="https://res.cloudinary.com/dbfn5lnvx/image/upload/v1645464030/learnhtmlcss/images/cat.jpg"
              src="https://i.pravatar.cc/300"
              height="40px"
              width="40px"
              className="popup-avatar"
              alt="avatar"
            />
            <div className="flex-space-between">
              <FaRegUserCircle />
              <span style={{ flex: 1 }}>{buyerInfo.buyerName}</span>
            </div>
            <div className="flex-space-between">
              <FaMapMarkerAlt />
              <span style={{ flex: 1 }}>{buyerInfo.buyerLocation}</span>
            </div>
          </div>
        )}
        <Divider
          orientation="vertical"
          variant="middle"
          flexItem
          sx={borderStyle}
        />
        <div className="energy-details flex-space-between-direction-column">
          <div className="energy-details-title" style={{ textAlign: "center" }}>
            <span>Energy Type</span>
          </div>
          <div>
            <Stack direction="row" spacing={1}>
              <Chip label="Electric Car" variant="filled" color="warning" />
            </Stack>
          </div>
        </div>
        <Divider
          orientation="vertical"
          variant="middle"
          flexItem
          sx={borderStyle}
        />
        <div className="energy-details flex-space-between-direction-column">
          <div className="energy-details-title" style={{ textAlign: "center" }}>
            <span>Required Energy</span>
          </div>
          <Box
            sx={{
              width: "150px",
            }}
          >
            <TextField
              id="outlined-basic"
              size="small"
              placeholder="Required energy"
              sx={textFieldStyle}
              disabled={props.searchLocationPoints}
              InputProps={{
                inputProps: {
                  style: {
                    color: "black",
                    backgroundColor: "#fff",
                    borderRadius: "8px",
                  },
                },
              }}
              name="energyVolume"
              onChange={props.onEnergyVolumeChangeEvent}
              value={props.energyVolume}
              autoComplete="off"
            />
          </Box>
        </div>
        <Divider
          orientation="vertical"
          variant="middle"
          flexItem
          sx={borderStyle}
        />
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <Box sx={{ m: 1, position: "relative" }}>
            <Button
              variant="contained"
              style={{boxShadow:"5px 5px 8px", border:"1px solid", borderRadius:"12px"}}
              disabled={
                props.energyVolume === "" || props.searchLocationPoints
                  ? true
                  : false
              }
              onClick={props.onSearchEvent}
            >
              Search
            </Button>
            {props.searchLocationPoints && (
              <CircularProgress
                sx={{
                  zIndex: 1000,
                  color: green[500],
                  position: "absolute",
                  top: 0,
                  bottom: 0,
                  left: 0,
                  right: 0,
                  margin: "auto",
                }}
              />
            )}
          </Box>
          {/* <Button variant="contained" style={{ backgroundColor: "#e20074" }}>
            Order History
          </Button> */}
        </Box>
      </Box>
    </>
  );
}
