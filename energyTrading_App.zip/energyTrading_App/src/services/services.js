import { ethers } from "ethers";
import { energyAbi, orderAbi } from "./constants";
import axios from "axios";

const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
const signer = provider.getSigner();

//pass in the smart contract address, smart contract ABI, provider:

const energyContract = new ethers.Contract(
  "0x443eeC5cEC754b855C85D7728166eb2d3708DAF4",
  energyAbi,
  provider
);

const orderContract = new ethers.Contract(
  // "0xc2a2932F107D85Fcfe436e16878A08749401dccA",
  "0x189bE3A58134eC7d79777Df25E9B1A6E37090aEf",
  orderAbi,
  signer
);

const energyChargingTimer = {};
const TIMER = `${process.env.ENERGY_REDUCTION_TIMER_IN_SECONDS}` || 4000;

const setIntervalForEnergyTransfer = (
  totalHits,
  wallet_address,
  seller_station_id,
  buyer_station_id,
  energyDelta,
  requiredEnergy,
  reminder,
  totalEnergy,
  orderId
) => {
  try {
    let x = 0;
    let sellerEnergyValue = totalEnergy - requiredEnergy;
    let buyerEnergyValue = totalEnergy + requiredEnergy;
    if (!!energyChargingTimer[wallet_address]) {
      delete energyChargingTimer[wallet_address];
    }
    energyChargingTimer[wallet_address] = {
      totalHits,
      hitsDone: x,
      energyDelta,
      requiredEnergy,
      reminder,
      sellerEnergyValue,
      buyerEnergyValue,
      isClearInterval: false,
    };
    let intervalID = setInterval(() => {
      try {
        if (!energyChargingTimer[wallet_address]) return;
        iotInstance
          .put(`/updateStationEnergy/${seller_station_id}`, {
            energyDelta: -energyDelta,
            isVehicleFueling: "InProgress",
          })
          .catch((error) => {
            console.error(error);
          });
        iotInstance
          .put(`/updateStationEnergy/${buyer_station_id}`, {
            energyDelta: energyDelta,
            isVehicleFueling: "InProgress",
          })
          .catch((error) => {
            console.error(error);
          });
        energyChargingTimer[wallet_address].hitsDone = ++x;
        if (x === totalHits) {
          clearInterval(intervalID);
          energyChargingTimer[wallet_address].isClearInterval = true;
          let seller_data = {
            isVehicleFueling: "Completed",
          };
          let buyer_data = {
            isVehicleFueling: "Completed",
          };
          if (reminder) {
            seller_data["energyDelta"] = -reminder;
            buyer_data["energyDelta"] = reminder;
          }
          iotInstance
            .put(`/updateStationEnergy/${seller_station_id}`, seller_data)
            .catch((error) => {
              console.error(error);
            });
          iotInstance
            .put(`/updateStationEnergy/${buyer_station_id}`, buyer_data)
            .catch((error) => {
              console.error(error);
            });

          iotInstance
            .put(`/updateAvailableEnergy/${seller_station_id}`, {
              availableEnergy: sellerEnergyValue,
            })
            .catch((error) => {
              console.error(error);
            });
          iotInstance
            .put(`/updateAvailableEnergy/${buyer_station_id}`, {
              availableEnergy: buyerEnergyValue,
            })
            .catch((error) => {
              console.error(error);
            });
        }
      } catch (error) {
        console.log(error);
      }
    }, TIMER);

    if (energyChargingTimer[wallet_address]["intervalID"]) {
      console.log("inside if");
      completeTransfer(orderId, false);
    } else {
      console.log("inside else");
      completeTransfer(orderId, true);
    }
  } catch (error) {
    console.error(error);
  }
};

const iotInstance = axios.create({
  baseURL: `http://20.96.116.65:80/api/v1`,
  timeout: 10000,
  headers: {
    "Content-Type": "application/json",
  },
});

export default async function getProsumersInfo() {
  try {
    // here need to change address by the run time add value from landing page
    const accountAddress = window.localStorage.getItem("accountAddr");
    //const accountAddress = "0x71bdad439e6c8e1ffe470291ff79570e3e286813"; // account-1
    // const accountAddress = "0xDa2a0572F3a1F797ce2824e5C2ec5C2AB1729D7e"; // account-2
    const prosumerInfo = await energyContract.getProsumersWithEnergy(
      accountAddress
    );
    console.log("Prosumer Address -> ", prosumerInfo["prosumer_obj"]);
    return prosumerInfo;
  } catch (error) {
    // throw new Error(error);
    console.log(error);
  }
}

export async function getProsumersWithEnergy(energyVal, addr) {
  try {
    const prosumerInfo = await energyContract.getAllProsumersWithEnergy();

    // Filtering for coordinates - starts
    // const filteredArray = prosumerInfo
    const filteredArray = prosumerInfo.filter((item) => {
      // const hex = parseInt(item[2][3]._hex);
      const hex = parseInt(item[2].amount);
      // Get the hex value from each item in the array and convert it to an integer
      const address = item[0]; // Get the address from each item in the array
      return (
        address.toLocaleLowerCase() !== addr.toLocaleLowerCase() &&
        hex > energyVal
      );
      // return address !== addr && hex > 0;
    });

    console.log("filtered array for coordinates --> ", filteredArray);
    // Filtering for coordinates - ends

    return filteredArray;
  } catch (error) {
    // throw new Error(error);
    console.log(error);
  }
}

export async function getAllOrders(buyer_address) {
  try {
    const orderInfo = await orderContract.getAllOrders();
    console.log("orderInfo for order history", orderInfo);
    return orderInfo;
  } catch (error) {
    // throw new Error(error);
    console.log(error);
  }
}

export async function placeTradingOrder(energyQty, sellerAddress) {
  try {
    const orderId = new Date().getTime().toString();

    // const provider = new ethers.providers.JsonRpcProvider({
    //   url: "https://volta-rpc.energyweb.org",
    // });

    // const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
    // const signer =  provider.getSigner();
    // console.log("orderId ->", orderId);

    const placeOrderInfo = await orderContract.placeTradingOrder(
      orderId,
      sellerAddress,
      energyQty,
      orderId
    );

    console.log("orderInfo for order history", placeOrderInfo);
    return placeOrderInfo;
  } catch (error) {
    // throw new Error(error);
    console.log(error);
    // console.log(error);
  }
}

export async function getAllBuyOrders(buyer_address) {
  try {
    const orderInfo = await orderContract.getAllOrders();
    console.log("orderInfo for order history", orderInfo);
    const filteredOrders = orderInfo.filter(
      (order) =>
        order.buyer.toLowerCase() === buyer_address.toLowerCase() &&
        order.buyer.toLowerCase() !== order.seller.toLowerCase()
    );
    console.log("orderInfo for order history", filteredOrders);
    return filteredOrders;
  } catch (error) {
    // throw new Error(error);
    console.log(error);
  }
}

export async function getAllSellOrders(seller_address) {
  try {
    const orderInfo = await orderContract.getAllOrders();
    console.log("orderInfo for order history", orderInfo);
    const filteredOrders = orderInfo.filter(
      (order) =>
        order.seller.toLowerCase() === seller_address.toLowerCase() &&
        order.seller.toLowerCase() !== order.buyer.toLowerCase()
    );
    console.log("orderInfo for order history", filteredOrders);
    return filteredOrders;
  } catch (error) {
    // throw new Error(error);
    console.log(error);
  }
}

export async function acceptedOrRejectTradingOrder(orderId, is_success) {
  try {
    const updated_at = new Date().getTime().toString();
    const placeOrderInfo = await orderContract.acceptedOrRejectTradingOrder(
      orderId,
      is_success,
      updated_at
    );

    // console.log("orderInfo for order history", placeOrderInfo);
    return placeOrderInfo;
  } catch (error) {
    // throw new Error(error);
    console.log(error);
  }
}

export async function payTradingOrder(orderId) {
  try {
    const updated_at = new Date().getTime().toString();

    const placeOrderInfo = await orderContract.payTradingOrder(
      orderId,
      updated_at
    );

    console.log("orderInfo for order history", placeOrderInfo);
    return placeOrderInfo;
  } catch (error) {
    // throw new Error(error);
    console.log(error);
  }
}

// export async function transferInitiatedOrder(orderId) {
//   try {
//     const updated_at = new Date().getTime().toString();
//     const placeOrderInfo = await orderContract.transferInitiatedOrder(
//       orderId,
//       updated_at
//     );
//     console.log("Infonfo for transit", placeOrderInfo);
//     return placeOrderInfo;
//   } catch (error) {
//      console.log(error)
//   }
// }

// export async function transferInitiatedOrder(orderId, seller_station_id, buyer_station_id, my_wallet_address, required_energy, transferRate, totalEnergy) {
export async function transferInitiatedOrder(orderId) {
  try {
    const updated_at = new Date().getTime().toString();
    const seller_station_id = 2;
    const buyer_station_id = 4;
    const my_wallet_address = "0xA3967031eF1b3CaE12A1d3dc84Ad1D91105FceB0";
    const required_energy = 30;
    const transferRate = 5;
    // const totalHits = parseInt(required_energy / transferRate);
    const totalHits = 2;
    console.log("totalHits", totalHits);
    const reminder = required_energy % transferRate;
    const totalEnergy = 300;
    const placeOrderInfo = await orderContract.transferInitiatedOrder(
      orderId,
      updated_at
    );
    const hits = setIntervalForEnergyTransfer(
      totalHits,
      my_wallet_address,
      seller_station_id,
      buyer_station_id,
      transferRate,
      required_energy,
      reminder,
      totalEnergy,
      orderId
    );
    console.log("hits", hits);
    console.log("orderInfo for order history", placeOrderInfo);
    return placeOrderInfo;
  } catch (error) {
    console.log(error);
  }
}

// async function checkTransactionStatus(transactionHash) {
//   // Connect to the Ethereum network using a provider
//   const provider = new ethers.providers.JsonRpcProvider("<YOUR_PROVIDER_URL>");

//   try {
//     // Get transaction details
//     const transaction = await provider.getTransaction(transactionHash);

//     if (transaction) {
//       // Check the transaction status
//       if (transaction.blockNumber) {
//         console.log(
//           "Transaction confirmed. Block number:",
//           transaction.blockNumber
//         );
//       } else {
//         console.log("Transaction pending");
//       }
//     } else {
//       console.log("Transaction not found");
//     }
//   } catch (error) {
//     console.error("Error checking transaction status:", error);
//   }
// }

async function completeTransfer(orderId, is_transfer_success) {
  console.log("orderId", orderId);
  console.log("is_transfer_success", is_transfer_success);

  // const provider = new ethers.providers.JsonRpcProvider({
  //     url: "https://volta-rpc.energyweb.org",
  //   })
  // // Create a signer with a private key or JSON wallet
  // const privateKey = '4ddb0098bc712377c146d1eb8509961efd7f489997a429023f72abda018d8002';
  // const signer = new ethers.Wallet(privateKey, provider);
  // console.log("signer", signer);
  // const orderContract = new ethers.Contract(
  //   "0x189bE3A58134eC7d79777Df25E9B1A6E37090aEf",
  //   orderAbi,
  //   signer
  // );
  // console.log("orderContract", orderContract);

  try {
    // const transfer_time_in_minutes = new Date().getTime().toString();
    const transfer_time_in_minutes = 2;

    const placeOrderInfo = await orderContract.completeTransfer(
      orderId,
      is_transfer_success,
      transfer_time_in_minutes
    );

    console.log("orderInfo for order history", placeOrderInfo);
    return placeOrderInfo;
  } catch (error) {
    console.log("error", error);
    // throw new Error(error);
    console.log(error);
  }
}

// export { getProsumersInfo, getProsumersWithEnergy };

// export default getProsumersWithEnergy;
