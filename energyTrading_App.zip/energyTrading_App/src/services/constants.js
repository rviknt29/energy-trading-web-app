export const orderAbi = [
  {
    inputs: [
      {
        internalType: "address",
        name: "_energy_contract",
        type: "address",
      },
    ],
    stateMutability: "nonpayable",
    type: "constructor",
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "string",
        name: "message",
        type: "string",
      },
    ],
    name: "Log",
    type: "event",
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "bytes",
        name: "data",
        type: "bytes",
      },
    ],
    name: "LogBytes",
    type: "event",
  },
  {
    inputs: [
      {
        internalType: "string",
        name: "_order_id",
        type: "string",
      },
      {
        internalType: "bool",
        name: "isAccepted",
        type: "bool",
      },
      {
        internalType: "string",
        name: "updation_date",
        type: "string",
      },
    ],
    name: "acceptedOrRejectTradingOrder",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool",
      },
    ],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "string",
        name: "_order_id",
        type: "string",
      },
      {
        internalType: "bool",
        name: "is_transfer_success",
        type: "bool",
      },
      {
        internalType: "string",
        name: "transfer_time_in_minutes",
        type: "string",
      },
    ],
    name: "completeTransfer",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool",
      },
    ],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [],
    name: "energyStore",
    outputs: [
      {
        internalType: "contract EnergyStoreInterface",
        name: "",
        type: "address",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "getAllOrders",
    outputs: [
      {
        components: [
          {
            internalType: "string",
            name: "order_id",
            type: "string",
          },
          {
            internalType: "address",
            name: "buyer",
            type: "address",
          },
          {
            internalType: "address",
            name: "seller",
            type: "address",
          },
          {
            internalType: "enum OrderStatus",
            name: "status",
            type: "uint8",
          },
          {
            internalType: "string",
            name: "txn_id",
            type: "string",
          },
          {
            internalType: "uint256",
            name: "total_cost",
            type: "uint256",
          },
          {
            internalType: "uint256",
            name: "energy_amount",
            type: "uint256",
          },
          {
            internalType: "enum EnergyUnit",
            name: "energy_unit",
            type: "uint8",
          },
          {
            internalType: "enum EnergySource",
            name: "energy_source",
            type: "uint8",
          },
          {
            internalType: "enum EnergyType",
            name: "energy_type",
            type: "uint8",
          },
          {
            internalType: "enum OrderType",
            name: "order_type",
            type: "uint8",
          },
          {
            internalType: "uint16",
            name: "transferRate",
            type: "uint16",
          },
          {
            internalType: "string",
            name: "creationDate",
            type: "string",
          },
          {
            internalType: "string",
            name: "updationDate",
            type: "string",
          },
          {
            internalType: "string",
            name: "completionDate",
            type: "string",
          },
          {
            internalType: "string",
            name: "energyTransferTimeInSeconds",
            type: "string",
          },
          {
            internalType: "uint16",
            name: "current",
            type: "uint16",
          },
          {
            internalType: "uint16",
            name: "voltage",
            type: "uint16",
          },
          {
            internalType: "bool",
            name: "is_exist",
            type: "bool",
          },
        ],
        internalType: "struct Order[]",
        name: "ordrerList",
        type: "tuple[]",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "string",
        name: "_order_id",
        type: "string",
      },
    ],
    name: "getOrder",
    outputs: [
      {
        components: [
          {
            internalType: "string",
            name: "order_id",
            type: "string",
          },
          {
            internalType: "address",
            name: "buyer",
            type: "address",
          },
          {
            internalType: "address",
            name: "seller",
            type: "address",
          },
          {
            internalType: "enum OrderStatus",
            name: "status",
            type: "uint8",
          },
          {
            internalType: "string",
            name: "txn_id",
            type: "string",
          },
          {
            internalType: "uint256",
            name: "total_cost",
            type: "uint256",
          },
          {
            internalType: "uint256",
            name: "energy_amount",
            type: "uint256",
          },
          {
            internalType: "enum EnergyUnit",
            name: "energy_unit",
            type: "uint8",
          },
          {
            internalType: "enum EnergySource",
            name: "energy_source",
            type: "uint8",
          },
          {
            internalType: "enum EnergyType",
            name: "energy_type",
            type: "uint8",
          },
          {
            internalType: "enum OrderType",
            name: "order_type",
            type: "uint8",
          },
          {
            internalType: "uint16",
            name: "transferRate",
            type: "uint16",
          },
          {
            internalType: "string",
            name: "creationDate",
            type: "string",
          },
          {
            internalType: "string",
            name: "updationDate",
            type: "string",
          },
          {
            internalType: "string",
            name: "completionDate",
            type: "string",
          },
          {
            internalType: "string",
            name: "energyTransferTimeInSeconds",
            type: "string",
          },
          {
            internalType: "uint16",
            name: "current",
            type: "uint16",
          },
          {
            internalType: "uint16",
            name: "voltage",
            type: "uint16",
          },
          {
            internalType: "bool",
            name: "is_exist",
            type: "bool",
          },
        ],
        internalType: "struct Order",
        name: "",
        type: "tuple",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256",
      },
    ],
    name: "orderIndex",
    outputs: [
      {
        internalType: "string",
        name: "",
        type: "string",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "string",
        name: "_order_id",
        type: "string",
      },
      {
        internalType: "string",
        name: "updation_date",
        type: "string",
      },
    ],
    name: "payTradingOrder",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool",
      },
    ],
    stateMutability: "payable",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "string",
        name: "_order_id",
        type: "string",
      },
      {
        internalType: "address",
        name: "_seller",
        type: "address",
      },
      {
        internalType: "uint256",
        name: "_energy_delta",
        type: "uint256",
      },
      {
        internalType: "string",
        name: "creation_date",
        type: "string",
      },
    ],
    name: "placeTradingOrder",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool",
      },
    ],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [],
    name: "prosumerStore",
    outputs: [
      {
        internalType: "contract ProsumerStoreInterface",
        name: "",
        type: "address",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "string",
        name: "_order_id",
        type: "string",
      },
      {
        internalType: "string",
        name: "updation_date",
        type: "string",
      },
    ],
    name: "transferInitiatedOrder",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool",
      },
    ],
    stateMutability: "nonpayable",
    type: "function",
  },
];

export const energyAbi = [
  {
    inputs: [
      {
        internalType: "address",
        name: "_prosumer_contract",
        type: "address",
      },
    ],
    stateMutability: "nonpayable",
    type: "constructor",
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "string",
        name: "message",
        type: "string",
      },
    ],
    name: "Log",
    type: "event",
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "bytes",
        name: "data",
        type: "bytes",
      },
    ],
    name: "LogBytes",
    type: "event",
  },
  {
    inputs: [
      {
        internalType: "string[]",
        name: "producerData",
        type: "string[]",
      },
      {
        internalType: "enum ProsumerType",
        name: "_prosumer_type",
        type: "uint8",
      },
      {
        internalType: "address",
        name: "prosumerAddress",
        type: "address",
      },
    ],
    name: "addProsumer",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool",
      },
    ],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "_producer",
        type: "address",
      },
      {
        internalType: "enum EnergySource",
        name: "_esource",
        type: "uint8",
      },
      {
        internalType: "enum EnergyType",
        name: "_etype",
        type: "uint8",
      },
      {
        internalType: "enum EnergyUnit",
        name: "_euint",
        type: "uint8",
      },
      {
        internalType: "uint16",
        name: "_transferRate",
        type: "uint16",
      },
      {
        internalType: "uint16",
        name: "_current",
        type: "uint16",
      },
      {
        internalType: "uint16",
        name: "_voltage",
        type: "uint16",
      },
      {
        internalType: "uint256",
        name: "_capacity",
        type: "uint256",
      },
      {
        internalType: "uint256",
        name: "energyAmount",
        type: "uint256",
      },
      {
        internalType: "uint256",
        name: "_price",
        type: "uint256",
      },
    ],
    name: "editEnergyStore",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool",
      },
    ],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [],
    name: "getAllProsumersWithEnergy",
    outputs: [
      {
        components: [
          {
            internalType: "address",
            name: "prosumer_address",
            type: "address",
          },
          {
            components: [
              {
                internalType: "address",
                name: "prosumer_address",
                type: "address",
              },
              {
                internalType: "string",
                name: "location",
                type: "string",
              },
              {
                internalType: "string",
                name: "geo_location_lat",
                type: "string",
              },
              {
                internalType: "string",
                name: "geo_location_long",
                type: "string",
              },
              {
                internalType: "string",
                name: "id",
                type: "string",
              },
              {
                internalType: "string",
                name: "name",
                type: "string",
              },
              {
                internalType: "string",
                name: "phone",
                type: "string",
              },
              {
                internalType: "string",
                name: "email",
                type: "string",
              },
              {
                internalType: "enum ProsumerType",
                name: "prosumer_type",
                type: "uint8",
              },
              {
                internalType: "bool",
                name: "is_exist",
                type: "bool",
              },
            ],
            internalType: "struct ProsumerData",
            name: "prosumer_obj",
            type: "tuple",
          },
          {
            components: [
              {
                internalType: "string",
                name: "id",
                type: "string",
              },
              {
                internalType: "address",
                name: "prosumer_address",
                type: "address",
              },
              {
                internalType: "enum EnergyType",
                name: "energy_type",
                type: "uint8",
              },
              {
                internalType: "enum EnergySource",
                name: "energy_source",
                type: "uint8",
              },
              {
                internalType: "enum EnergyUnit",
                name: "energy_unit",
                type: "uint8",
              },
              {
                internalType: "uint16",
                name: "transferRate",
                type: "uint16",
              },
              {
                internalType: "uint16",
                name: "current",
                type: "uint16",
              },
              {
                internalType: "uint16",
                name: "voltage",
                type: "uint16",
              },
              {
                internalType: "uint256",
                name: "capacity",
                type: "uint256",
              },
              {
                internalType: "uint256",
                name: "amount",
                type: "uint256",
              },
              {
                internalType: "uint256",
                name: "price",
                type: "uint256",
              },
              {
                internalType: "bool",
                name: "is_exist",
                type: "bool",
              },
            ],
            internalType: "struct EnergyData",
            name: "energy_store_arr",
            type: "tuple",
          },
        ],
        internalType: "struct ProsumerEnergyStoreStruct[]",
        name: "prosumerList",
        type: "tuple[]",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "_producer",
        type: "address",
      },
    ],
    name: "getEnergyStore",
    outputs: [
      {
        components: [
          {
            internalType: "string",
            name: "id",
            type: "string",
          },
          {
            internalType: "address",
            name: "prosumer_address",
            type: "address",
          },
          {
            internalType: "enum EnergyType",
            name: "energy_type",
            type: "uint8",
          },
          {
            internalType: "enum EnergySource",
            name: "energy_source",
            type: "uint8",
          },
          {
            internalType: "enum EnergyUnit",
            name: "energy_unit",
            type: "uint8",
          },
          {
            internalType: "uint16",
            name: "transferRate",
            type: "uint16",
          },
          {
            internalType: "uint16",
            name: "current",
            type: "uint16",
          },
          {
            internalType: "uint16",
            name: "voltage",
            type: "uint16",
          },
          {
            internalType: "uint256",
            name: "capacity",
            type: "uint256",
          },
          {
            internalType: "uint256",
            name: "amount",
            type: "uint256",
          },
          {
            internalType: "uint256",
            name: "price",
            type: "uint256",
          },
          {
            internalType: "bool",
            name: "is_exist",
            type: "bool",
          },
        ],
        internalType: "struct EnergyData",
        name: "",
        type: "tuple",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "getProsumerStoreContractObject",
    outputs: [
      {
        internalType: "contract ProsumerStore",
        name: "",
        type: "address",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "_producer",
        type: "address",
      },
    ],
    name: "getProsumersWithEnergy",
    outputs: [
      {
        components: [
          {
            internalType: "address",
            name: "prosumer_address",
            type: "address",
          },
          {
            components: [
              {
                internalType: "address",
                name: "prosumer_address",
                type: "address",
              },
              {
                internalType: "string",
                name: "location",
                type: "string",
              },
              {
                internalType: "string",
                name: "geo_location_lat",
                type: "string",
              },
              {
                internalType: "string",
                name: "geo_location_long",
                type: "string",
              },
              {
                internalType: "string",
                name: "id",
                type: "string",
              },
              {
                internalType: "string",
                name: "name",
                type: "string",
              },
              {
                internalType: "string",
                name: "phone",
                type: "string",
              },
              {
                internalType: "string",
                name: "email",
                type: "string",
              },
              {
                internalType: "enum ProsumerType",
                name: "prosumer_type",
                type: "uint8",
              },
              {
                internalType: "bool",
                name: "is_exist",
                type: "bool",
              },
            ],
            internalType: "struct ProsumerData",
            name: "prosumer_obj",
            type: "tuple",
          },
          {
            components: [
              {
                internalType: "string",
                name: "id",
                type: "string",
              },
              {
                internalType: "address",
                name: "prosumer_address",
                type: "address",
              },
              {
                internalType: "enum EnergyType",
                name: "energy_type",
                type: "uint8",
              },
              {
                internalType: "enum EnergySource",
                name: "energy_source",
                type: "uint8",
              },
              {
                internalType: "enum EnergyUnit",
                name: "energy_unit",
                type: "uint8",
              },
              {
                internalType: "uint16",
                name: "transferRate",
                type: "uint16",
              },
              {
                internalType: "uint16",
                name: "current",
                type: "uint16",
              },
              {
                internalType: "uint16",
                name: "voltage",
                type: "uint16",
              },
              {
                internalType: "uint256",
                name: "capacity",
                type: "uint256",
              },
              {
                internalType: "uint256",
                name: "amount",
                type: "uint256",
              },
              {
                internalType: "uint256",
                name: "price",
                type: "uint256",
              },
              {
                internalType: "bool",
                name: "is_exist",
                type: "bool",
              },
            ],
            internalType: "struct EnergyData",
            name: "energy_store_arr",
            type: "tuple",
          },
        ],
        internalType: "struct ProsumerEnergyStoreStruct",
        name: "",
        type: "tuple",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "string",
        name: "_id",
        type: "string",
      },
    ],
    name: "getProsumersWithEnergyById",
    outputs: [
      {
        components: [
          {
            internalType: "address",
            name: "prosumer_address",
            type: "address",
          },
          {
            components: [
              {
                internalType: "address",
                name: "prosumer_address",
                type: "address",
              },
              {
                internalType: "string",
                name: "location",
                type: "string",
              },
              {
                internalType: "string",
                name: "geo_location_lat",
                type: "string",
              },
              {
                internalType: "string",
                name: "geo_location_long",
                type: "string",
              },
              {
                internalType: "string",
                name: "id",
                type: "string",
              },
              {
                internalType: "string",
                name: "name",
                type: "string",
              },
              {
                internalType: "string",
                name: "phone",
                type: "string",
              },
              {
                internalType: "string",
                name: "email",
                type: "string",
              },
              {
                internalType: "enum ProsumerType",
                name: "prosumer_type",
                type: "uint8",
              },
              {
                internalType: "bool",
                name: "is_exist",
                type: "bool",
              },
            ],
            internalType: "struct ProsumerData",
            name: "prosumer_obj",
            type: "tuple",
          },
          {
            components: [
              {
                internalType: "string",
                name: "id",
                type: "string",
              },
              {
                internalType: "address",
                name: "prosumer_address",
                type: "address",
              },
              {
                internalType: "enum EnergyType",
                name: "energy_type",
                type: "uint8",
              },
              {
                internalType: "enum EnergySource",
                name: "energy_source",
                type: "uint8",
              },
              {
                internalType: "enum EnergyUnit",
                name: "energy_unit",
                type: "uint8",
              },
              {
                internalType: "uint16",
                name: "transferRate",
                type: "uint16",
              },
              {
                internalType: "uint16",
                name: "current",
                type: "uint16",
              },
              {
                internalType: "uint16",
                name: "voltage",
                type: "uint16",
              },
              {
                internalType: "uint256",
                name: "capacity",
                type: "uint256",
              },
              {
                internalType: "uint256",
                name: "amount",
                type: "uint256",
              },
              {
                internalType: "uint256",
                name: "price",
                type: "uint256",
              },
              {
                internalType: "bool",
                name: "is_exist",
                type: "bool",
              },
            ],
            internalType: "struct EnergyData",
            name: "energy_store_arr",
            type: "tuple",
          },
        ],
        internalType: "struct ProsumerEnergyStoreStruct",
        name: "",
        type: "tuple",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "_buyer_address",
        type: "address",
      },
      {
        internalType: "uint256",
        name: "energyDelta",
        type: "uint256",
      },
    ],
    name: "isCapacity",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "_seller_address",
        type: "address",
      },
      {
        internalType: "uint256",
        name: "energyDelta",
        type: "uint256",
      },
    ],
    name: "isEnergyAvailable",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "_buyer_address",
        type: "address",
      },
      {
        internalType: "address",
        name: "_seller_address",
        type: "address",
      },
    ],
    name: "matchBuyerWithSeller",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "prosumerStore",
    outputs: [
      {
        internalType: "contract ProsumerStore",
        name: "",
        type: "address",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "_producer",
        type: "address",
      },
      {
        internalType: "uint256",
        name: "energyDelta",
        type: "uint256",
      },
      {
        internalType: "bool",
        name: "is_add",
        type: "bool",
      },
    ],
    name: "updateEnergyAmount",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool",
      },
    ],
    stateMutability: "nonpayable",
    type: "function",
  },
];

export const magentaTrustABI = [
  {
    inputs: [
      {
        internalType: "address",
        name: "_registryAddress",
        type: "address",
      },
      {
        internalType: "string",
        name: "_name",
        type: "string",
      },
      {
        internalType: "bytes32",
        name: "docHash",
        type: "bytes32",
      },
      {
        internalType: "bytes32",
        name: "docsMerkelRoot",
        type: "bytes32",
      },
    ],
    name: "createDossier",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "string",
        name: "issuerName",
        type: "string",
      },
      {
        internalType: "address",
        name: "issuerAddress",
        type: "address",
      },
      {
        internalType: "bytes32",
        name: "docHash",
        type: "bytes32",
      },
      {
        internalType: "bytes32",
        name: "docsMerkelRoot",
        type: "bytes32",
      },
    ],
    name: "MagentaTrust__DocumentAlreadyExists",
    type: "error",
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "bytes32",
        name: "docHash",
        type: "bytes32",
      },
      {
        indexed: false,
        internalType: "bytes32",
        name: "docsMerkelRoot",
        type: "bytes32",
      },
      {
        indexed: false,
        internalType: "address",
        name: "issuerAddress",
        type: "address",
      },
    ],
    name: "documentStored",
    type: "event",
  },
  {
    inputs: [
      {
        internalType: "bytes32",
        name: "docHash",
        type: "bytes32",
      },
      {
        internalType: "bytes32[]",
        name: "merkleProof",
        type: "bytes32[]",
      },
    ],
    name: "validateDocument",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
];

// export default abi
